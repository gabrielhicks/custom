/**
 * Copyright IBM Corporation 2009-2017
 *
 * Licensed under the Eclipse Public License - v 1.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.eclipse.org/legal/epl-v10.html
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * @Author Doug Wood
 **/
package psdi.webclient.components;

import java.beans.Beans;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.ibm.json.java.JSONObject;

import psdi.app.asset.AssetSetRemote;
import psdi.app.bim.BIMService;
import psdi.app.bim.Constants;
import psdi.app.bim.viewer.BuildingModel;
import psdi.app.bim.viewer.BuildingModelSet;
import psdi.app.bim.viewer.BuildingModelSetRemote;
import psdi.app.location.Location;
import psdi.app.location.LocationRemote;
import psdi.app.location.LocationSetRemote;
import psdi.mbo.MboRemote;
import psdi.mbo.MboSetInfo;
import psdi.mbo.MboSetRemote;
import psdi.mbo.SqlFormat;
import psdi.security.UserInfo;
import psdi.server.MXServer;
import psdi.util.MXApplicationException;
import psdi.util.MXException;
import psdi.webclient.beans.asset.AssetAppBean;
import psdi.webclient.beans.bim.viewer.AssetLookup;
import psdi.webclient.beans.bim.viewer.AssetLookupMulti;
import psdi.webclient.beans.bim.viewer.BIMViewerEventBean;
import psdi.webclient.beans.bim.viewer.ModelAppBean;
import psdi.webclient.beans.bim.viewer.WOModelLocBean;
import psdi.webclient.beans.location.LocationAppBean;
import psdi.webclient.beans.workorder.WOAppBean;
import psdi.webclient.controls.TabGroup;
import psdi.webclient.system.beans.AppBean;
import psdi.webclient.system.beans.DataBean;
import psdi.webclient.system.beans.ResultsBean;
import psdi.webclient.system.beans.WebClientBean;
import psdi.webclient.system.controller.AppInstance;
import psdi.webclient.system.controller.BaseInstance;
import psdi.webclient.system.controller.BoundComponentInstance;
import psdi.webclient.system.controller.ControlInstance;
import psdi.webclient.system.controller.PageInstance;
import psdi.webclient.system.controller.WebClientEvent;
import psdi.webclient.system.session.WebClientSession;

/**
 * Component class to expose an API for integrating 3D BIM viewers with Maximo.
 * The reference implementation is the Autodesk NavisWOrks ActiveX control
 * 
 * <table>
 * 	<tr>
 * 		<td><b>Prefix</b></td><td><b>Use</b></td>
 * 	</tr>
 * 	<tr>
 * 		<td>event</td><td>Call from control jsp via JavaScript sentEvent function</td>
 * 	</tr>
 * 	<tr>
 * 		<td>jsp</td><td>Call from control jsp to dynamically generate JavaScriptn</td>
 * 	</tr>
 * 	<tr>
 * 		<td>jsp</td><td>Call from control jsp to dynamically generate JavaScriptn</td>
 * 	</tr>
 * </table>
 * 
 * @author Doug Wood
 */
public class BIMViewer extends BoundComponentInstance {
    public final static int VERSION_LESS_THAN_7116 = BIMService.VERSION_LESS_THAN_7116;
    public final static int VERSION_7116_OR_GREATER = BIMService.VERSION_7116_OR_GREATER;
    public final static int VERSION_75_OR_GREATER = BIMService.VERSION_75_OR_GREATER;


    public final static String PROP_DATA_ATTRIB = "dataattribute";
    public final static String PROP_MODEL_ATTRIB = "modelattribute";
    public final static String PROP_CTRL_TARGET = "controltarget";

    public final static String FIELD_ASSETUID = "ASSETUID";
    public final static String FIELD_ASSETNUM = "ASSETNUM";
    public final static String FIELD_BUILDINGMODELID = "BUILDINGMODELID";
    public final static String FIELD_ORGID = "ORGID";
    public final static String FIELD_SITEID = "SITEID";
    public final static String FIELD_LOCATION = "LOCATION";
    public final static String FIELD_LOCATIONUID = "LOCATIONSID";
    public final static String FIELD_MODELID = "MODELID";
    public final static String FIELD_NETWORK = "NETWORK";
    public final static String FIELD_PARENT = "PARENT";
    public final static String FIELD_PRIMARYSYSTEM = "PRIMARYSYSTEM";
    public final static String FIELD_SYSTEMID = "SYSTEMID";
    public final static String FIELD_WO_NUM = "WONUM";

    public final static String TABLE_ASSET = "ASSET";
    public final static String TABLE_LOCATIONS = "LOCATIONS";
    public final static String TABLE_WORKORDER = "WORKORDER";
    public final static String TABLE_LOCACCESTOR = "LOCACCESTOR";
    public final static String TABLE_LOCHIERARCHY = "LOCHIERARCHY";
    public final static String TABLE_LOCSYSTEM = "LOCSYSTEM";

    public final static String HOST_PARAM_MARKER = "<HOSTNAME>";

    /**
     * Used to store the current resize option in the HTTP Session
     */
    public final static String ATTRIB_RESIZE = "bim.resize";
    public final static String ATTRIB_RESIZE_DLG = "bim.resize.dlg";

    public final static int TYPE_UNKNOWN = 0;
    public final static int TYPE_ASSET = 1;
    public final static int TYPE_LOCATION = 2;
    public final static int TYPE_LOOKUP = 3;
    public final static int TYPE_WORKORDER = 4;
    public final static int TYPE_MODEL = 5;

    public final static int RECORD_UNKNOWN = 0;
    public final static int RECORD_ASSET = 1;
    public final static int RECORD_LOCATION = 2;
    public final static int RECORD_MODEL = 3;

    // 1 =:modelid, 2 =:modelLocation 3 =:SiteId
    private final static String QUERY_LOC_MODELID =
        "=:1 and location in ( select location from locancestor where ancestor =:2 " +
        " and systemid in (select systemid from locsystem where siteid =:3 and primarysystem = 1) ) ";

    private final static String QUERY_MODEL_FILE =
        "location in (select ancestor from locancestor where location =:1 and siteid =:2 and systemid =:3) and siteid =:2";

    private MXServer _server;
    private WebClientSession _wcs = null;

    /**
     * Get an instance of the building model set to use for quering building models
     */
    private BuildingModelSetRemote _modelSet;

    /**
     * Indication the type of application the control is associated with
     * Determined by the class of the data bean 
     */
    private int _type = TYPE_UNKNOWN;

    /**
     * The base type of the parent Mbo
     */
    private int _recordType = RECORD_UNKNOWN;

    /**
     * Track if the model file has change from the last one loaded
     */
    private Vector < BIMModelSpec > _currentModelList = new Vector < BIMModelSpec > ();
    private boolean _hasModelListChanged = true;
    private String _currentValue = "";
    private boolean _hasValueChanged = true;

    /**
     * Forces the model file list cache to be flushed and reloaded
     */
    private boolean _forceUpdate = false;

    /**
     * Tracks if the control should allow the user to select more that a single
     * item - True when the control is used for multi-select lookup on the
     * Service Request and Work order applications
     * 
     * This value is set at initilzation based on the class of the parent
     * DataBean
     */
    private boolean _isMultiSelectAllowed = false;

    /**
     * Tracks the currently selected value in the model viewer.
     * Updated by eventSetContext sent from the .jsp a
     */
    private String _lookupValue = null;

    /**
     * Tracks if the app is mapped into the visible are of the screen
     */
    private boolean _controlVisible = false;

    /**
     * Set of all values in the current selection
     * Used by dialogs that ned the current selection
     */
    private Set < String > _currentSelection;

    /**
     * Set of item to push to the model for selection.
     * Cleared after push.  The viewer has different behavior for single and
     * multi selections
     */
    private Set < String > _multiSelection = null;

    /**
     * Determines if the multiSelect call requests a zoom to context.  This is set to true
     * by the eventMultiSelect method and set to false in the jspScript method when a request
     * is made
     */
    private boolean _multeSelectZoomToContext = false;

    /**
     * Used to communicate back to the .jsp the results of a eventSerContext.
     * If the model ID sent in the event is not found in Maximo, this is
     * set to false
     */
    private boolean _isSelectionValid = true;

    /**
     * The name of the Mbo field used to map elements of the model
     * to Maximo.  It must be unique within siteid
     * 
     * This is read from the datattribtue value if the UI if specified.
     * The default is "assetnum" for asset and "location" for location 
     */
    private String _binding = null;

    /**
     * Specified in the presentation XML.  When the control is bound to
     * an Asset MBO, the is the filed in the parent location for the
     * current asset that is used for selecting items in the model
     */
    private String _modelId = null;

    /**
     * The calue of the location field of the Macimo location record with which the
     * model currenly displayed in the viewer is assocated
     * <p>
     * It is set by the eventSelect method.  could be null if nothing is selected
     */
    private String _modelLocation = null;

    /**
     * Controls if selecting items in the viewer up date the current maximo 
     * contect.  If false, the eventSelect is not processed
     */
    private boolean selectionEnabled = true;

    /**
     * Although the control appears on a tab, it is really in the client 
     * area. To maintain the appears of being on a tab, it must manage its
     * visibility based on the current;y displayed tab.  The following 
     * attributes provide the refresh method the name of the tab group
     * the control is part of and the name of the tab that the control 
     * should be visible when selected
     */
    private String _tabGroupName = null;
    private String _tabName = null;

    /**
     * Used to push updates to the status line of the control 
     */
    private String _statusUpdate = null;

    private String _width = "950px";
    private int _height = 468;
    private int _controlTop = 0;
    private int _controlLeft = 0;
    private int _topOffset = 0;
    private int _leftOffset = 0;

    /**
     * used to control version specific implementations in the linked .jsp
     */
    private int _mxVersion = VERSION_LESS_THAN_7116;

    private String _activeViewer = "navisworks";

    private DataBean eventBean = null;

    public void instantiatedatasrc() {
        super.instantiatedatasrc();
        //System.out.println(">>> instantiatedatasrc: " + dataBean.getId());
    }

    private void setupEventClass() {
        WebClientSession wcs = getWebClientSession();
        String eventClassName = getProperty("eventclass");

        if ((eventClassName != null) && (!eventClassName.equals(""))) {
            ControlInstance creator = wcs.getCurrentEventHandler();
            try {
                ClassLoader classLoader = getClass().getClassLoader();
                this.eventBean = ((DataBean) Beans.instantiate(classLoader, eventClassName));
                this.eventBean.setId(getId());
                this.eventBean.setCreator(creator);
                this.eventBean.setupBean(wcs);
            } catch (ClassNotFoundException ex) {
                System.err.println("Could not instantiate eventclass for control " + creator.getId() + " because the implentation class " + eventClassName + " was not found");
            } catch (Exception exc) {
                exc.printStackTrace();
            }
        }
    }

    public int handleEvent(String methodName, WebClientEvent event)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        if (this.eventBean != null) {
            Object evtResult = Integer.valueOf(2);
            try {
                Class ec = this.eventBean.getClass();	
                Method m = ec.getMethod(methodName, null);
                evtResult = Integer.valueOf(((Integer) m.invoke(this.eventBean, null)).intValue());
                event.setProcessed();
                event.getWebClientSession().serviceability.requests.addHandledBy(event, this);
                if ((evtResult instanceof Integer)) {
                	if(((Integer) evtResult).intValue() == WebClientBean.EVENT_CONTINUE) // if the event handler wants the event to continue, let it
                	{
                        return super.handleEvent(methodName, event);
                	}
                    return ((Integer) evtResult).intValue();
                }
                return WebClientBean.EVENT_CONTINUE;
            } catch (Exception localException) {}	
        }

        return super.handleEvent(methodName, event);
    }

    public void initialize() {
        super.initialize();

        setupEventClass();

        _wcs = getWebClientSession();
        _controlVisible = false;
        _currentSelection = new HashSet < String > ();

        try {
            //System.out.println(">>> BIMViewer component check1" );
            _server = MXServer.getMXServer();

            String version = _server.getMaxupgValue();
            if (version.compareTo("V7116") >= 0) {
                _mxVersion = VERSION_7116_OR_GREATER;
            }
            if (version.compareTo("V75") >= 0) {
                _mxVersion = VERSION_75_OR_GREATER;
            }
            if (version.compareTo("V76") >= 0) {
                _mxVersion = VERSION_75_OR_GREATER;
            }

            //System.out.println(">>> BIMViewer component check2" );
            try {
                _activeViewer = _server.getProperty(BIMService.PROP_NAME_ACTIVE_VIEWER);
            } catch (Exception e) {
                e.printStackTrace();
            }


            //			MboRemote mbo = getDataBean().getMbo(0);
            //System.out.println(">>> BIMViewer component check3" );
            DataBean db = getDataBean();
            //System.out.println(">>> BIMViewer component check3.3" );
            MboSetRemote mboSet = null;
            try {
                //System.out.println(">>> BIMViewer component check3.5" );
                mboSet = db.getMboSet();
            } catch (Exception e) {
                //System.out.println(">>> BIMViewer component check3.7" );
                e.printStackTrace();
            }
            //System.out.println(">>> BIMViewer component check3.9" );
            UserInfo userInfo = mboSet.getUserInfo();
            //System.out.println(">>> BIMViewer component check4" );
            //System.out.println(">>> BIMViewer component initialize, mboSet: " + mboSet );
            if (mboSet instanceof AssetSetRemote) {
                _recordType = RECORD_ASSET;
            } else if (mboSet instanceof LocationSetRemote) {
                _recordType = RECORD_LOCATION;
            } else if (mboSet instanceof BuildingModelSet) {
                _recordType = RECORD_MODEL;
            }


            _modelSet = (BuildingModelSetRemote) _server.getMboSet("BUILDINGMODEL", userInfo);
            _modelSet.setWhere("siteid is null");
            _modelSet.reset();

            if (!setupControlType(dataBean)) {
                DataBean bean = dataBean.getParent();
                setupControlType(bean);
            }

        } catch (Exception e) {
            // Do nothing type is TYPE_UNKNOWN
        }

        String binding = getProperty(PROP_DATA_ATTRIB);
        if (binding != null && binding.length() > 0) {
            _binding = binding;
        }
        _modelId = getProperty(PROP_MODEL_ATTRIB);
        if (_modelId == null || _modelId.length() == 0) {
            _modelId = binding;
        }
        if (_modelId == null || _modelId.length() == 0) {
            _modelId = "modelid";
        }
        _tabGroupName = getProperty("tabgroup");
        if (_tabGroupName == null || _tabGroupName.length() == 0) {
            _tabGroupName = "maintabs";
        }
        _tabName = getProperty("tab");
        if (_tabName == null || _tabName.length() == 0) {
            _tabName = "view";
        }

        // Require for the Create WOrk ORder button when bound to asset
        setProperty(BoundComponentInstance.ATTRIBUTE_NAME, _binding);

        String tmp = getProperty("topoffset");
        if (tmp != null && tmp.length() > 0) {
            _topOffset = Integer.parseInt(tmp);
        }
        tmp = getProperty("leftoffset");
        if (tmp != null && tmp.length() > 0) {
            _leftOffset = Integer.parseInt(tmp);
        }

        tmp = getProperty("height");
        //		_height = Integer.parseInt( tmp );
        //		if( _height <= 0 )
        //		{
        //			_height = 368;
        //		}
        _height = ((tmp == null || tmp.equals("")) ? 1 : Integer.parseInt(tmp));

        // This might be 100% or some other CSS string value
        _width = getProperty("width");
        _width = ((_width == null || _width.equals("")) ? "1" : _width);

        tmp = getProperty("controltop");
        _controlTop = ((tmp == null || tmp.equals("")) ? 0 : Integer.parseInt(tmp));

        tmp = getProperty("controlleft");
        _controlLeft = ((tmp == null || tmp.equals("")) ? 0 : Integer.parseInt(tmp));

        //		int intVal = -1;
        //		try
        //		{ 
        //			intVal = Integer.parseInt( _width );
        //		}
        //		catch( Throwable T )
        //		{ /* Do Nothing */ }
        //		if( intVal > 0 )
        //		{
        //			_width = "" + (intVal - _leftOffset);
        //		}

        tmp = getProperty("selection_enabled");
        if (tmp != null && tmp.length() > 0) {
            if (tmp.equalsIgnoreCase("FALSE")) {
                selectionEnabled = false;
            }
        }

        if (_type == TYPE_WORKORDER) {
            AppInstance app = getWebClientSession().getCurrentApp();
            try {
                if (app.isSigOptionCheck("BIMVIEWER")) {
                    _wcs.queueEvent(new WebClientEvent("bimviewer", getId(), _binding, _wcs));
                }
            } catch (MXException mxe) {
                // Ignore event not queued if there is not access
            }
        } else if (_type == TYPE_LOOKUP) {
            _wcs.queueEvent(new WebClientEvent("bimviewer", getId(), _binding, _wcs));
        }
    }

    private boolean setupControlType(
        DataBean bean
    ) {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        if (bean instanceof AssetAppBean) {
            _type = TYPE_ASSET;
            return true;
        }
        if (bean instanceof LocationAppBean) {
            _type = TYPE_LOCATION;
            _isMultiSelectAllowed = true;
            return true;
        }
        if (bean instanceof AssetLookup) {
            _type = TYPE_LOOKUP;
            return true;
        }
        if (bean instanceof AssetLookupMulti) {
            _type = TYPE_LOOKUP;
            _isMultiSelectAllowed = true;
            return true;
        }
        if (bean instanceof WOAppBean || dataBean instanceof WOModelLocBean) {
            _type = TYPE_WORKORDER;
            _isMultiSelectAllowed = true;
            return true;
        }
        if (bean instanceof ModelAppBean) {
            _type = TYPE_MODEL;
            _isMultiSelectAllowed = false;
            return true;
        }

        return false;
    }

    @Override
    public int render()
    throws NoSuchMethodException,
    IllegalAccessException,
    InvocationTargetException {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        //		//System.out.println(">>> BIMViewer component render stacktrace?");
        //		StringWriter sw = new StringWriter();
        //		(new Exception()).printStackTrace(new PrintWriter(sw));
        //		System.out.println(sw.toString());

        checkVisibility();
        return super.render();
    }

    /**
     * Determine if the control is visible or on a tab that is hidden
     * @return
     */
    public int checkVisibility() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        PageInstance currentPage = getPage();
        TabGroup maintab = (TabGroup) currentPage.getControlInstance(_tabGroupName);
        boolean shouldAppVis = true;
        if (maintab != null) {
            shouldAppVis = maintab.getCurrentTab().getId().equalsIgnoreCase(_tabName);
        }
        if (shouldAppVis != isControlVisible()) {
            //System.out.println(">>> BIMViewer component " + ((new Object() {}).getClass().getEnclosingMethod().getName()) + " setControlVisible change..." );
            setControlVisible(shouldAppVis);
            setChangedFlag();
        }
        return WebClientBean.EVENT_HANDLED;
    }

    //**************************************************************************
    // This section has handler for messages sent from the .jsp
    //**************************************************************************
    /**
     * Called from the viewer .jsp every time the selection is changed.
     * The event parameter is string that is a ; delimited set of values.
     * The first value in the list is the the location ID for the model. 
     * The second value is the currently selected item.  The
     * remaining members are the members of the selection set including
     * the selected item
     * @return
     * @throws RemoteException
     * @throws MXException
     */
    public int eventSelect()
    throws RemoteException,
    MXException {
    	//System.out.println(">>> BIMViewer.java eventSelect");
        //System.out.println(">>> BIMViewer component 3 " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        if (!selectionEnabled) {
            return WebClientBean.EVENT_HANDLED;
        }

        WebClientEvent event = _wcs.getCurrentEvent();
        Object o = event.getValue();
        if (o == null || !(o instanceof String)) {
            // Should never happen unless the .jsp is altered
            return WebClientBean.EVENT_HANDLED;
        }
        String result[] = ((String) o).split(";");
        //System.out.println(">>> BIMViewer component event value: " + ((String)o) );

        _currentSelection = new HashSet < String > ();

        if (result.length < 2) // Shouldn't happen
        {
            return WebClientBean.EVENT_HANDLED;
        }

        for (int i = 2; i < result.length; i++) {
            _currentSelection.add(result[i]);
        }
        _modelLocation = result[0];
    	//System.out.println(">>> BIMViewer.java eventSelect setCurrentSelection " + result[1]);
        setCurrentSelection(result[1]);
        return WebClientBean.EVENT_HANDLED;
    }

    /**
     * Called from the .jsp when the user selects a new size for the control.  
     * The size is saved in the session so it persists across refreshes
     */
    public void eventRezise() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        WebClientEvent event = _wcs.getCurrentEvent();
        Object o = event.getValue();
        HttpServletRequest thisRequest = _wcs.getRequest();
        HttpSession session = thisRequest.getSession();
        session.setAttribute(ATTRIB_RESIZE, o);
    }

    /**
     * Called from the .jsp when the user selects a new size for the control and 
     * the control is displayed on a dialog. The size is saved in the session so 
     * it persists across refreshes
     */
    public void eventReziseDlg() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        WebClientEvent event = _wcs.getCurrentEvent();
        Object o = event.getValue();
        HttpServletRequest thisRequest = _wcs.getRequest();
        HttpSession session = thisRequest.getSession();
        session.setAttribute(ATTRIB_RESIZE_DLG, o);
    }

    protected void updateCurrentSelection(
        String value
    ) {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        _currentSelection = new HashSet < String > ();
        if (value != null & !value.equals("")) {
            _currentSelection.add(dataBean.getString(FIELD_MODELID));
        }
    }

    /**
     * Makes an item selected in the viewer the current Maximo record
     * @param locationId	The location field value of the location associated with
     *                      the current model file
     * @param modelId		The modelId of the item in the model to select
     * @return				True if the requested selection is found
     * @throws RemoteException
     * @throws MXException
     */
    private boolean setCurrentSelection(
        String modelId
    )
    throws RemoteException, MXException {
    	//System.out.println(">>> BIMViewer.java setCurrentSelection: " + modelId);
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        long uid = lookupUid(modelId);
    	//System.out.println(">>> BIMViewer.java setCurrentSelection2: " + uid);

        if (uid == -1) {
            setNotFoundStatus();
            _isSelectionValid = false;
            return false;
        }
//        long oldUid = dataBean.getUniqueIdValue();
//        if (oldUid == uid) {
        if (_currentValue != null && _currentValue.equalsIgnoreCase(modelId)) {
            return true;
        }
        _currentValue = modelId;
        if (dataBean instanceof AppBean) {
        	//System.out.println(">>> BIMViewer.java setCurrentSelection3: " + uid);
            AppInstance app = _wcs.getCurrentApp();
            AppBean appBean = (AppBean) dataBean;
            if (appBean.saveYesNoInteractionCheck()) {
                //changeBeanRecordSet(appBean, uid);
                //				appBean.getMboForUniqueId( uid );
                //				dataBean.fireDataChangedEvent();
                //				dataBean.fireStructureChangedEvent();
            	//System.out.println(">>> BIMViewer.java setCurrentSelection4: " + uid);
                changeAppBeanRecordSet(app, appBean, uid);
                _isSelectionValid = true;
            }
        } else {
            changeBeanRecordSet(dataBean, uid);
        	//System.out.println(">>> BIMViewer.java setCurrentSelection5: " + uid);
            dataBean.getMboForUniqueId(uid);
            dataBean.fireDataChangedEvent();
            dataBean.fireStructureChangedEvent();
            _isSelectionValid = true;
        }

        if (dataBean instanceof AssetLookup) {
            _lookupValue = modelId;
        }
        return true;
    }

    private void changeAppBeanRecordSet(AppInstance app, AppBean appBean, long uid)
    throws RemoteException, MXException {
        ResultsBean resultsBean = app.getResultsBean();
        int recordToSelect = findInMboSet(uid, resultsBean.getMboSet());
        if(recordToSelect == -1) { // Add to results list if the selected record is not present
            String userWhere = resultsBean.getCompleteWhere(); // preserve complete where
            userWhere = userWhere.isEmpty() ? userWhere : userWhere + " or ";
            userWhere = userWhere + "( " + appBean.getUniqueIdName() + " = " + uid + " )";
            appBean.initializeApp(); // clears the results where
            resultsBean.resetQbe();
            resultsBean.setUserWhere(userWhere); // puts it back
            resultsBean.reset();
        }

        MboSetRemote resultsList = resultsBean.getMboSet();
        recordToSelect = findInMboSet(uid, resultsList);

        if(recordToSelect != -1) {
            resultsBean.highlightrow(recordToSelect);
        }

    }
    
    private int findInMboSet(long uid, MboSetRemote mboSet) throws RemoteException, MXException {
        int recordToSelect = 0;
        MboRemote mbo = mboSet.getMbo(recordToSelect);

        while (mbo != null) {
            if (mbo.getUniqueIDValue() == uid) {
                break;
            }
            mbo = mboSet.getMbo(++recordToSelect);
        }
        recordToSelect = (mbo == null) ? -1 : recordToSelect;
        
        return recordToSelect;
    }

    //******************************************************************************
    // The section has methods that are called from the .jsp to move data from
    // Maximo to the .jsp.  Many of the methods clear the data once it is transfered
    //
    // These methods should not be used except by the .jsp
    //******************************************************************************

    public Set < String > jspGetMultiSelection() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        Set < String > selection = _multiSelection;
        _multiSelection = null;
        return selection;
    }

    public String jspGetCurrentDataMM() throws RemoteException, MXException {
        StringBuffer script = new StringBuffer();
        
        if (this.eventBean != null) {
            String curData = ((BIMViewerEventBean) this.eventBean).getCurrentData(getProperty("attributespassed"));
	        script.append("maximoToViewerMessage( ");
	        script.append("{\"funcCall\": \"populateCurrentData\", \"passVar\": " + curData + "} ");
	        script.append("); ");
        }
//        if (this.eventBean != null) {
//            String curData = ((BIMViewerEventBean) this.eventBean).getCurrentData(getProperty("attributespassed"));
//            script.append("");
//            script.append("if( mm.populateCurrentData != undefined ) { ");
//            script.append("mm.populateCurrentData( ");
//            script.append(curData);
//            script.append(" ); ");
//            script.append(" } else if( frame.populateCurrentData != undefined ) { ");
//            script.append("frame.populateCurrentData( ");
//            script.append(curData);
//            script.append(" ); ");
//            script.append(" } ");
//        }

        return script.toString();
    }

    public String jspGetCurrentDataFrame() throws RemoteException, MXException {
        StringBuffer script = new StringBuffer();

        if (this.eventBean != null) {
            String curData = ((BIMViewerEventBean) this.eventBean).getCurrentData(getProperty("attributespassed"));
            script.append("");
            script.append("if( frame.populateCurrentData != undefined ) { ");
            script.append("frame.populateCurrentData( ");
            script.append(curData);
            script.append(" ); ");
            script.append(" } ");
        }

        return script.toString();
    }

    /**
     * Generate JavaScript to configure the current state of the control
     * <p>
     * This method supports the following control states and changes between those states:
     * - The entire control is either in its proper position on the screen or is "Stored"
     *   off the top of the screen
     * - There is a model file for the current bound value and the active X control is 
     *   displayed, or there is not and it is hidden and a message is displayed
     * - If it is a partial refresh and the HTML does not need to be rerendered, then this
     *   code is executed inside a script tag in the hidden frame.  IF it is run as part 
     *   of rendering the control then it is run wint the control HTML in the MAINDOC
     * - If it is a partial refresh, it may update the selected value, the both the model file
     *   and the selected value, or post a message to the status line
     */
    boolean jspInitialized = false;
    public String jspScript(
        String id
    )
    throws RemoteException,
    MXException {

        StringBuffer script = new StringBuffer();
        String containerTable = id + "container";
        String containerDiv = id + "_frameLoc";
        String controlTarget = getProperty(PROP_CTRL_TARGET);
        boolean designmode = _wcs.getDesignmode();
        boolean needsRendered = needsRender();
        ControlInstance bimTarget = null;
        if (controlTarget != null && !controlTarget.equalsIgnoreCase("")) {
            bimTarget = getWebClientSession().getCurrentApp().getCurrentPage().getControlInstance(controlTarget);
        }
        BaseInstance bimParent = getParentInstance();
        
        if(!isControlVisible() && !jspInitialized) {
        	return "";
        }

        //If the code is run in the hidden frame, then calls need to be prefixed with
        // MAINDOC this only applies to pre 7.5 versions
        String doc = "";
        if (!needsRendered &&
            getMxVersion() < VERSION_75_OR_GREATER) {
            doc = "MAINDOC.";
        }
        
        script.append("");
        script.append( "debugger;" );
//    	if(!isControlVisible() && bimTarget != null && bimParent != null)
//    	{
//            script.append("var containerDiv = " + doc + "document.getElementById( \"");
//            script.append(containerDiv);
//            script.append("\" ); ");
//            
//            script.append("var targetDiv = " + doc + "document.getElementById( \"");
//            script.append(bimTarget.getRenderId() + "_bimtarget_targ");
//            script.append("\" ); ");
//            
//            script.append("var bimOrigParent = " + doc + "document.getElementById( \"");
//            script.append(bimParent.getRenderId() + "_0");
//            script.append("\" ); ");
//            
//            script.append("if (containerDiv != null && targetDiv != null && bimOrigParent != null) {");
//	            script.append("if (containerDiv.parentElement == targetDiv && containerDiv.parentElement != bimOrigParent) {");
//		            script.append("containerDiv.style.visibility = \"hidden\";");
//		            script.append("bimOrigParent.appendChild(containerDiv);");
//	            script.append("}");
//            script.append("}");
//    	    
//    		return script.toString();
//    	}
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );

        // Set the top value
        script.append("try {");
        script.append("var containerTbl = " + doc + "document.getElementById( \"");
        script.append(containerTable);
        script.append("\" ); ");
        script.append("if( containerTbl != undefined ) { ");
        script.append("containerTbl.style.top = \"" + jspGetViewerTop() + "px\";");
        script.append("containerTbl.style.left = \"" + _leftOffset + "px\";");
        script.append("}");

        script.append("var containerDiv = " + doc + "document.getElementById( \"");
        script.append(containerDiv);
        script.append("\" ); ");
        // initialize the viewer position, height and width prior to resize
        if (isControlVisible()) {
            if (controlTarget != null && !controlTarget.equalsIgnoreCase("")) {
                bimTarget = getWebClientSession().getCurrentApp().getCurrentPage().getControlInstance(controlTarget);
                if (bimTarget != null) {
                    script.append("var targetDiv = " + doc + "document.getElementById( \"");
                    script.append(bimTarget.getRenderId() + "_bimtarget_targ");
                    script.append("\" ); ");
                    script.append("if(containerDiv != null && targetDiv != null) { ");
                    //script.append("frame.placeViewer(containerDiv, targetDiv); ");
                    script.append("if(containerDiv.parentElement != targetDiv) { ");
                    
                    script.append("targetDiv.viewerContainerParent = containerDiv.parentElement.id; ");
                    script.append("targetDiv.viewerContainer = containerDiv.id; ");
                    
                    //script.append("targetDiv.appendChild(containerDiv); ");
                    script.append("containerDiv.style.visibility = \"visible\"; ");
                    script.append("containerDiv.style.display = \"block\"; ");
                    script.append("moveToTarg(\"" + containerDiv + "\", \"" + bimTarget.getRenderId() + "_bimtarget_targ" + "\");");
            		
                    if(!jspInitialized) { // create viewerframe the first time that the viewer is displayed
	                    script.append("var viewerframe = \"" + getWebClientSession().getMaximoRequestContextURL() + "/webclient/components/bim" + getViewerType() + "/viewerframe.jsp?rid=" + id + "&id=" + getId() + "&uisessionid=" + getWebClientSession().getUISessionID()+ "\"; ");
	                    script.append("var iframe = document.createElement(\"iframe\"); ");
	                    script.append("iframe.frameBorder = 0; ");
	                    script.append("iframe.id = \"" + id + "_frame\"; ");
	                    script.append("iframe.setAttribute(\"src\", viewerframe); ");
	                    script.append("containerDiv.appendChild(iframe); ");
	                	jspInitialized = true;
                    }

            		script.append("var theFrame = " + doc + "document.getElementById( \"");
                    script.append(id + "_frame");
                    script.append("\" ); ");
                    script.append("if(theFrame != null && theFrame != undefined) { ");
                    script.append("targetDiv.style.border = \"0px\"; ");
                    script.append("containerDiv.style.height = targetDiv.style.height; ");
                    script.append("containerDiv.style.width = targetDiv.style.width; ");
                    script.append("theFrame.style.height = containerDiv.style.height; ");
                    script.append("theFrame.style.width = containerDiv.style.width; ");
                    script.append("maximoToViewerMessage( ");
                    script.append("{\"funcCall\": \"resizeCtrl\", \"passVar\": {\"height\": theFrame.style.height, \"width\": theFrame.style.width} } ");
                    script.append("); ");
                    script.append("} ");
                    script.append("} ");
                    script.append(" } ");

                }
            }
        }

/*
        script.append("var isLoaded = true; ");
        script.append("var AF = " + doc + "document.getElementById( \"");
        script.append(id + "_frame");
        script.append("\" ); ");
        script.append("var frame = AF; ");
        //script.append( "AF = window.frames." + id + "_frame; " );
        //script.append( "var frame = window.top.frames." + id + "_frame; " );
        script.append("if( frame != undefined && frame.contentWindow != undefined ) { ");
        script.append("frame = frame.contentWindow;"); // Chrome
        script.append("} ");
        script.append("if( frame == undefined || frame.setModelVisibility == undefined ) { ");
        script.append("isLoaded = false; ");
        script.append("} ");

        // The controls has two forms:  
        // - A message indicating there is no model file
        // - The actual control
        // The correct form is selected based on wether the current location has a model file
        //
        // If the control is alredy displayed, then it may be necessary to select between
        // The message window and the control window. Its simpler to always set these values
        // The to track the current state
        boolean showModel = false;
        //script.append(scriptResize());

        String visHid = (isControlVisible() ? "visible" : "hidden");
        script.append("if(containerDiv != null) { ");
        script.append("containerDiv.style.visibility = \"");
        script.append(visHid);
        script.append("\"; ");
        script.append(" } ");

*/
        String value = null;
        boolean showModel = false;
        if (isControlVisible()) {
            showModel = itemHasModel();
            value = getValue();
//            script.append("if( isLoaded ) { ");
//            script.append("frame.setModelVisibility( ");
//            script.append(showModel);
//            script.append(" ); ");
//            script.append("} ");

            //			script.append( "var containerDivHeight = parseInt(containerDiv.style.height, 10); " );
            //			script.append( "var containerDivWidth = parseInt(containerDiv.style.width, 10); " );
            //			script.append( "frame.resizeTo(containerDivHeight, containerDivWidth); " );
            //			script.append( "console.log(containerDivHeight + \", \" +  containerDivWidth); " );

        }
        //script.append( "var jdbg = \">>> isControlVisible: " + isControlVisible() + " showModel: " + showModel + " designmode: " + designmode + "\";" );  
//        script.append("maximoToViewerMessage( ");
//        script.append("{\"funcCall\": \"testMessageFromMaximo\", \"passVar\": \"this is a message from the bimviewer control\"} ");
//        script.append("); ");
//        script.append("maximoToViewerMessage( ");
//        script.append("{\"funcCall\": \"testMessageFromMaximo\", \"passVar\": \"this is a SECOND message from the bimviewer control\"} ");
//        script.append("); ");
//        script.append("maximoToViewerMessage( ");
//        script.append("{\"funcCall\": \"testMessageFromMaximo\", \"passVar\": \"this is a THIRD message from the bimviewer control\"} ");
//        script.append("); ");

        if ((isModelListChanged()) || (needsRendered)) {
            script.append("maximoToViewerMessage( ");
            script.append("{\"funcCall\": \"initModelManager\", \"passVar\": null} ");
            script.append("); ");
            
            script.append(jspGetCurrentDataMM());
            
            script.append("maximoToViewerMessage( ");
            script.append("{\"funcCall\": \"resetModelList\", \"passVar\": null} ");
            script.append("); ");
            
            script.append(jspGetScriptModelList());
            
            script.append("maximoToViewerMessage( ");
            script.append("{\"funcCall\": \"populateModelList\", \"passVar\": \"" + value + "\"} ");
            script.append("); ");
            
            setModelListChanged(false);
            setValueChanged(false);
        } else if (((isValueChanged()) || (needsRendered)) && (getAppType() != 3)) {
            script.append(jspGetCurrentDataMM());
            
            script.append("maximoToViewerMessage( ");
            script.append("{\"funcCall\": \"select\", \"passVar\": \"" + value + "\"} ");
            script.append("); ");
            
            setValueChanged(false);
        }
        
/*        
        boolean curDataLoaded = false;
        //View tab is selected so the control should be visible on the page
        if (isControlVisible() && !designmode) {
            boolean hasScript = false;
            if (jspHasStatusUpdate()) {
                script.append("frame.setStatus( \"");
                script.append(jspGetStatusUpdate().trim());
                script.append("\" ); ");
                hasScript = true;
            }


            if (isHasMultiSelect()) {
                Set < String > selection = jspGetMultiSelection();
                Iterator < String > itr = selection.iterator();
                script.append("var selection = new Array(); ");
                while (itr.hasNext()) {
                    script.append("selection[ selection.length ] = \"");
                    script.append(itr.next());
                    script.append("\"; ");
                }
                script.append("frame.multiSelect( selection, \"");
                script.append(value);
                script.append("\", ");
                if (_multeSelectZoomToContext) {
                    script.append("true");
                } else {
                    script.append("false");
                }
                script.append(" ); ");

                _multeSelectZoomToContext = false;
                hasScript = true;
            }

            if (hasScript) {
                script.append("} catch( e ) { console.log( \"BIMViewer error\\\n\" ); console.log( e ); }");
                return script.toString();
            }

            // If the model file has changed due to a change in the value bound to
            // the control, or the control is being rerendered, then the models
            // must be reloaded into the control
            script.append("var jdbg2 = \">>> isModelListChanged(): " + isModelListChanged() + " needsRendered: " + needsRendered + " isValueChanged(): " + isValueChanged() + " getAppType(): " + getAppType() + "\";");
            if ((isModelListChanged()) || (needsRendered)) {
                script.append("if( isLoaded ) { ");
                script.append("var mm = frame.initModelManager(); ");
                script.append("if( mm != null ) { ");

                script.append(jspGetCurrentDataMM());
                curDataLoaded = true;

                script.append("mm.resetModelList(); ");
                script.append(jspGetScriptModelList());
                script.append("mm.populateModelList( \"");
                script.append(value);
                script.append("\" ); ");
                script.append("} ");
                script.append("} ");
            } else if (((isValueChanged()) || (needsRendered)) &&
                (getAppType() != 3)) {
                script.append("if( isLoaded ) { ");
                
                script.append(jspGetCurrentDataFrame());
                curDataLoaded = true;
                
                script.append("frame.select( \"");
                script.append(value);
                script.append("\" ); ");

                script.append("} ");
                setValueChanged(false);
            }
        } // close if( isControlVisible() )

        if ((isControlVisible()) && (!designmode) && !curDataLoaded) {
            script.append(jspGetCurrentDataFrame());
        }

        if (needsRendered && getAppType() != TYPE_LOOKUP) {
            // Stack<AppInstance> appStack = _wcs.getAppStack(); Might sometime fixe return from app
            if (!getViewerType().equals("lmv")) {
                script.append(" rehideObjs();");
            }
        }
*/
        script.append("} catch( e ) { console.log( e ); }");

        return script.toString();

    }

    public String scriptResize() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        StringBuffer resize = new StringBuffer();
        resize.append("");
        if (!isControlVisible()) {
            resize.append("if( isLoaded ) { frame.resize( \"-1\" ); }");
            return resize.toString();
        }

        int opt;
        if (getAppType() == BIMViewer.TYPE_LOOKUP) {
            resize.append("if( isLoaded ) { frame.resizeDlg( \"");
            opt = jspGetRezieDlgOption();
        } else {
            resize.append("if( isLoaded ) { frame.resize( \"");
            opt = jspGetRezieOption();
        }

        resize.append(opt);
        resize.append("\" ); } ");

        _width = getWidthFromResize(opt);
        _height = getHeightFromResize(opt);

        return resize.toString();
    }

    private String getWidthFromResize(int opt) {
        // note: we're only handling resize options 1 through 7.  -1 and 0 are special cases
        String widths[] = new String[] {
            "1200",
            "1024",
            "1280",
            "1920",
            "1600",
            "1920",
            "1200"
        };
        if (opt > 0 && ((opt - 1) < widths.length)) {
            return widths[opt - 1];
        }
        return _width;
    }

    private int getHeightFromResize(int opt) {
        // note: we're only handling resize options 1 through 7.  -1 and 0 are special cases
        int heights[] = {
            720,
            768,
            1024,
            1080,
            1200,
            1200,
            800
        };
        if (opt > 0 && ((opt - 1) < heights.length)) {
            return heights[opt - 1];
        }
        return _height;
    }

    /**
     * Generate JavaScript to add all the models in _currentModelList
     * to the ComboBox specified by listCtrlId
     * @param listCtrlId
     * @return JavaScript fragment
     */
    public String jspGetScriptModelList() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        StringBuffer script = new StringBuffer();

        for (int i = 0; i < _currentModelList.size(); i++) {
            BIMModelSpec modelSpec = _currentModelList.get(i);
			JSONObject jsonData = new JSONObject();
			
	        jsonData.put("modelId", modelSpec.getModelId());
	        jsonData.put("location", modelSpec.getLocation());
	        jsonData.put("binding", modelSpec.getBinding());
            if (modelSpec.getTitle() != null && modelSpec.getTitle().length() > 0) {
    	        jsonData.put("title", modelSpec.getTitle());
            } else if (modelSpec.getDescription() != null && modelSpec.getDescription().length() > 0) {
    	        jsonData.put("title", modelSpec.getDescription());
            } else {
    	        jsonData.put("title", modelSpec.getLocationName());
            }
	        jsonData.put("url", modelSpec.getModelURL());
	        jsonData.put("attribClass", modelSpec.getAttribClass());
	        jsonData.put("attribName", modelSpec.getAttribName());
	        jsonData.put("paramClass", modelSpec.getParamClass());
	        jsonData.put("paramName", modelSpec.getParamName());
            if (_type == TYPE_ASSET) {
    	        jsonData.put("defaultView", modelSpec.getAssetView());
            } else if (_type == TYPE_LOCATION) {
    	        jsonData.put("defaultView", modelSpec.getLocationView());
            } else if (_type == TYPE_LOOKUP) {
    	        jsonData.put("defaultView", modelSpec.getLookupView());
            } else if (_type == TYPE_WORKORDER) {
    	        jsonData.put("defaultView", modelSpec.getWorkOrderView());
            }
	        jsonData.put("selectionMode", modelSpec.getSelectionMode());
	        jsonData.put("siteId", modelSpec.getSiteId());
            String mboKey = getMboKey();
            if (mboKey != null && mboKey.length() > 0) {
    	        jsonData.put("mboKey", mboKey);
            }
			
	        script.append("maximoToViewerMessage( ");
	        script.append("{\"funcCall\": \"addModel\", \"passVar\": " + jsonData.toString() + "} ");
	        script.append("); ");
            
//            script.append("mm.addModel(");
//            script.append(modelSpec.getModelId());
//            script.append(", \"");
//            script.append(modelSpec.getLocation());
//            script.append("\", \"");
//            script.append(modelSpec.getBinding());
//            script.append("\", \"");
//            if (modelSpec.getTitle() != null && modelSpec.getTitle().length() > 0) {
//                script.append(modelSpec.getTitle());
//            } else if (modelSpec.getDescription() != null && modelSpec.getDescription().length() > 0) {
//                script.append(modelSpec.getDescription());
//            } else {
//                script.append(modelSpec.getLocationName());
//            }
//            script.append("\", \"");
//            script.append(modelSpec.getModelURL());
//            script.append("\", \"");
//            script.append(modelSpec.getAttribClass());
//            script.append("\", \"");
//            script.append(modelSpec.getAttribName());
//            script.append("\", \"");
//            script.append(modelSpec.getParamClass());
//            script.append("\", \"");
//            script.append(modelSpec.getParamName());
//            script.append("\", \"");
//            if (_type == TYPE_ASSET) {
//                script.append(modelSpec.getAssetView());
//            } else if (_type == TYPE_LOCATION) {
//                script.append(modelSpec.getLocationView());
//            } else if (_type == TYPE_LOOKUP) {
//                script.append(modelSpec.getLookupView());
//            } else if (_type == TYPE_WORKORDER) {
//                script.append(modelSpec.getWorkOrderView());
//            }
//            script.append("\", \"");
//            script.append(modelSpec.getSelectionMode());
//            script.append("\", \"");
//            script.append(modelSpec.getSiteId());
//            String mboKey = getMboKey();
//            if (mboKey != null && mboKey.length() > 0) {
//                script.append("\", \"");
//                script.append(mboKey);
//            }
//            script.append("\" ); ");
        }

        _hasModelListChanged = false;
        String tmp = script.toString();
        //System.out.println(">>> ModelList: " + tmp);
        return tmp;
    }

    public String scriptFooter() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        StringBuffer footer = new StringBuffer();
        footer.append("");
        return footer.toString();
    }

    /**
     * Retrieves a stored resize option from the HTTP session and makes it 
     * available to the .jsp.  This version is used when the viewer is
     * displayed on an application main tab
     * @return
     */
    public int jspGetRezieOption() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        HttpServletRequest thisRequest = _wcs.getRequest();
        HttpSession session = thisRequest.getSession();
        Object o = session.getAttribute(ATTRIB_RESIZE);
        if (o == null || !(o instanceof String)) {
            return 0;
        }
        String option = (String) o;
        if (option.length() == 0) {
            return 0;
        }
        return Integer.parseInt(option);
    }

    /**
     * Retrieves a stored resize option from the HTTP session and makes it 
     * available to the .jsp.  This version is used when the viewer is
     * displayed on an dialog
     * @return
     */
    public int jspGetRezieDlgOption() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        HttpServletRequest thisRequest = _wcs.getRequest();
        HttpSession session = thisRequest.getSession();
        Object o = session.getAttribute(ATTRIB_RESIZE_DLG);
        if (o == null || !(o instanceof String)) {
            return 0;
        }
        String option = (String) o;
        if (option.length() == 0) {
            return 0;
        }
        return Integer.parseInt(option);
    }



    /**
     * Provides an update to the control status line and resets
     * hasStatusUpdate to false
     * @return Test of status update
     */
    public String jspGetStatusUpdate() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        if (_statusUpdate == null) return ""; // Shouldm't be called in this situation
        String status = _statusUpdate;
        _statusUpdate = null;
        return status;
    }


    /**
     * If the control is displayed on a tab of an application, its really not on the tab,
     * it at the bottom of the page below the tab set.  This prevents reloading of the
     * control and of control data as the use moved between tabs.  To cause it to 
     * display correctly, the control class tracks which tab is visible and if the 
     * control should be displayed.  If it should, top is set to a value on the tab
     * if it shouldn't, top is set to a large negative value
     * @return
     */
    public int jspGetViewerTop() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        //Is the control on the screen or in "Storage"?
        if (isControlVisible()) {
            return _topOffset;
        }
        return -5000;
    }

    /**
     * Indicates if there is a status message to display on the control
     * Status line
     * @return True if there is a status message
     */
    public boolean jspHasStatusUpdate() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _statusUpdate != null;
    }

    //******************************************************************************

    /**
     * Allows the .jsp to to application type specific processing 
     * including setting appopiate lable text
     * @return The type of the applcation the controls is supporting
     */
    public int getAppType() { //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _type;
    }

    public String getBackgroundColor() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        String color = getProperty("background_color");
        if (color != null && color.length() > 0) {
            return color;
        }
        String skin = _wcs.getSkin();
        if (skin.contains("tivoli09") || skin.contains("tivoli13")) {
            return "#FFFFFF";
        }
        return "#000000";
    }

    public String getBoarderColor() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        String color = getProperty("boarder_color");
        if (color != null && color.length() > 0) {
            return color;
        }
        String skin = _wcs.getSkin();
        if (skin.contains("tivoli09") || skin.contains("tivoli13")) {
            return "#E0E0E0";
        }
        return "#808080";
    }

    public String getForegroundColor() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        String color = getProperty("foreground_color");
        if (color != null && color.length() > 0) {
            return color;
        }
        String skin = _wcs.getSkin();
        if (skin.contains("tivoli09") || skin.contains("tivoli13")) {
            return "#000000";
        }
        return "#FFFFFF";
    }

    public String getHighlightColor() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        String color = getProperty("highlight_color");
        if (color != null && color.length() > 0) {
            return color;
        }
        String skin = _wcs.getSkin();
        if (skin.contains("tivoli09") || skin.contains("tivoli13")) {
            return "#0404B0";
        }
        return "#40B040";
    }

    public String getBinding() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _binding;
    }

    public Set < String > getCurrentSelection() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _currentSelection;
    }

    public int getHeight() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _height;
    }

    public int getControlTop() {
        return _controlTop;
    }

    public int getControlLeft() {
        return _controlLeft;
    }

    /**
     * Get the key value for the bound Mbo: Location, assetnum, wonum
     */
    public String getMboKey() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        switch (_type) {
            case TYPE_ASSET:
                return dataBean.getString(FIELD_ASSETNUM);
            case TYPE_LOCATION:
                return dataBean.getString(FIELD_LOCATION);
            case TYPE_WORKORDER:
                AppInstance app = getWebClientSession().getCurrentApp();
                DataBean db = app.getAppBean();
                return db.getString(FIELD_WO_NUM);
            case TYPE_MODEL:
                return dataBean.getString(FIELD_BUILDINGMODELID);
            case TYPE_LOOKUP:
                return "";
        }
        return "";
    }

    public int getLeftOffset() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _leftOffset;
    }

    public String getLookupValue() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _lookupValue;
    }

    public int getMxVersion() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _mxVersion;
    }

    /**
     * Allows the .jsp to do application type specific processing 
     * including setting appropriate label text
     * @return The type of the application the controls is supporting
     */
    public int getRecordType() { //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _recordType;
    }

    public String getSiteId() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return dataBean.getString(FIELD_SITEID);
    }

    public String getValue() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        String value = getString();
        if (!_binding.equalsIgnoreCase(_modelId)) {
        	value = dataBean.getString(_modelId);
        }
        if (value == null) value = "";

        if (!value.equalsIgnoreCase(_currentValue)) { 
            _hasValueChanged = true;
        }
        _currentValue = value;
//        String modelId = value;
//        if (!_binding.equalsIgnoreCase(FIELD_MODELID)) {
//            modelId = dataBean.getString(FIELD_MODELID);
//        }
//        return modelId;
        return value;
    }

    public String getViewerType() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        try {
            MXServer server = MXServer.getMXServer();
            String activeViewer = server.getProperty(BIMService.PROP_NAME_ACTIVE_VIEWER);
            if (activeViewer != null && activeViewer.length() > 0) {
                return activeViewer;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "navisworks";
    }

    public String getWidth() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _width;
    }

    public boolean isForceUpdate() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _forceUpdate;
    }

    public boolean isHasMultiSelect() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _multiSelection != null;
    }

    /**
     * <p>
     * Searches up the location hierarchy using the parent attribute of each location
     * looking for a building model file.
     * @return
     * @throws RemoteException
     * @throws MXException
     */
    private boolean itemHasModel()
    throws RemoteException,
    MXException {
        //System.out.println(">>> itemHasModel 1552");
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        Vector < BIMModelSpec > modelList;
        String leafLocation = null;
        if (getRecordType() == RECORD_MODEL) {
            BIMModelSpec modelSpec;
            modelList = new Vector < BIMModelSpec > ();
            modelSpec = new BIMModelSpec(dataBean);
            //System.out.println(">>> BIMViewer component itemHasModel 1 loc name: " + modelSpec.getLocationName() + " loc id: " + modelSpec.getLocation() + " binding: " + modelSpec.getBinding() + " model: " + modelSpec.getModelId() + " model url: " + modelSpec.getModelURL() );
            if (modelSpec.getModelURL() != null && modelSpec.getModelURL().length() > 0) {
                modelList.add(modelSpec);
            }
        } else {
            //System.out.println(">>> BIMViewer component itemHasModel 2 ELSE getRecordType() == RECORD_MODEL" );
            // call to getValue() sets the isValueChanged flag
            getValue();
            //System.out.println(">>> BIMViewer component itemHasModel isValueChanged(): " + isValueChanged() + " _forceUpdate: " + _forceUpdate + " _currentModelList: " + _currentModelList );
            //if( !isValueChanged() && !_forceUpdate )
            //			if( _forceUpdate == true )
            //			{
            //				if( _currentModelList == null )     return false;
            //				if( _currentModelList.size() == 0 ) return false;
            //				return true;
            //			}
            _forceUpdate = false;

            LocationRemote location = lookupLeafLocation();

            modelList = new Vector < BIMModelSpec > ();
            String field = _binding;
            if (_recordType == RECORD_ASSET) {
                field = _modelId;
            }

            //System.out.println(">>> BIMViewer component itemHasModel location: " + location );
            if (location != null) {
	            leafLocation = location.getString(FIELD_LOCATION);
	
	            MboSetRemote modelSet = lookupModelFileForLocation(location);
	            int count = 0;
	            try {
	                count = modelSet.count();
	            } catch (Exception e) { /* Ignor.  May happen if the bim.activ.viewer sys prop is incorrectly set */ }
	
	            for (int i = 0; modelSet != null && i < count; i++) {
	                MboRemote model = modelSet.getMbo(i);
	                location = lookupLocation(model.getString(FIELD_LOCATION));
	                //System.out.println(">>> BIMViewer component itemHasModel 3 location: " + location + " model: " + model );
	                if (model != null) {
	                    String locationName = location.getString(FIELD_LOCATION);
	                    String locationId = location.getString(FIELD_LOCATION);
	                    //System.out.println(">>> itemHasModel 1603");
	                    String binding = null;
	                    if(location.getThisMboSet().getMboSetInfo().getAttribute(field) != null)
	                    {
		                    binding = location.getString(field);
	                    }
	                    //System.out.println(">>> itemHasModel 1609");
	
	                    //			        BIMModelSpec modelSpec = new BIMModelSpec();
	                    BIMModelSpec modelSpec = new BIMModelSpec(locationName, locationId, binding, model);
	                    //System.out.println(">>> BIMViewer component itemHasModel 4 loc name: " + modelSpec.getLocationName() + " loc id: " + modelSpec.getLocation() + " binding: " + modelSpec.getBinding() + " model: " + modelSpec.getModelId() + " model url: " + modelSpec.getModelURL() );
	                    if (modelSpec.getModelURL() != null && modelSpec.getModelURL().length() > 0) {
	                        modelList.add(modelSpec);
	                    }
	                }
	            }
            }
        }

        BIMModelSpec modelSpec;
        if (modelList.size() > 0) {
            modelSpec = modelList.get(0);
        } else {
        	// if a model record doesn't exist, create a dummy
        	modelList.add(new BIMModelSpec());
            modelSpec = modelList.get(0);
            _modelLocation = null;
            _currentSelection = new HashSet < String > ();
            _currentSelection.add(dataBean.getString(FIELD_MODELID));
            _currentModelList = modelList;
            leafLocation = null;
        }
        if (!compareModelLists(_currentModelList, modelList)) {
            //System.out.println(">>> BIMViewer component itemHasModel 5 model list has changed." );
            _hasModelListChanged = true;
            _modelLocation = null;
            _currentSelection = new HashSet < String > ();
            _currentSelection.add(dataBean.getString(FIELD_MODELID));
            if (!modelList.isEmpty()) {
            	if(leafLocation == null)
            	{
                    modelSpec = modelList.elementAt(0);
                    _wcs.queueEvent(new WebClientEvent("bimModelListChanged", getId(), modelSpec.getLocation(), _wcs));
            	}
            }
        }
        
    	if(leafLocation != null)
    	{
            _wcs.queueEvent(new WebClientEvent("bimModelListChanged", getId(), leafLocation, _wcs));
    	}
    	
        _currentModelList = modelList;
        if (modelList.size() > 0) {
            //System.out.println(">>> BIMViewer component (modelList.size() > 0) " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        }
        if (modelList.size() > 0) return true;
        //System.out.println(">>> BIMViewer component (just returned false, so modelList.size() <= 0) " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return false;
    }

    /**
     * Track if the list of models in the location hierarchy from the
     * current asset of location up to the building has changed
     * @return
     */
    public boolean isModelListChanged() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _hasModelListChanged;
    }

    /**
     * Determines if the user is allowed to select more than one item at a time
     * @return 
     */
    public boolean isMultiSelectAllowed() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _isMultiSelectAllowed;
    }

    public boolean isSelectionValid() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _isSelectionValid;
    }

    public void forceUpdate() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        _forceUpdate = true;
    }

    public void setModelListChanged(boolean state) {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        _hasModelListChanged = state;
    }

    private void setNotFoundStatus() {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        if (_recordType == RECORD_ASSET) {
            _statusUpdate = getProperty("msg_not_asset");
        } else if (_recordType == RECORD_LOCATION) {
            _statusUpdate = getProperty("msg_not_location");
        } else {
            return; // No message needed
        }
        setChangedFlag();
    }

    /**
     * Track if the selected value is different form the currently
     * selected value to allow optimization
     */
    public boolean isValueChanged() { //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _hasValueChanged;
    }
    public void setValueChanged(boolean state) {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        _hasValueChanged = state;
    }


    public boolean isControlVisible() { //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        return _controlVisible;
    }
    public void setControlVisible(boolean vis) {
        //System.out.println(">>> BIMViewer component vis:" + vis + " " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        _controlVisible = vis;
    }

    /**
     * 
     * @param selection	A set of items using the value bound to the control to display as the 
     *        current selection in the control
     *        
     *        Called from dialogs that use the model as a display mechanism
     * @throws RemoteException
     * @throws MXException
     */
    public void setMultiSelect(
        String modelLocation,
        Set < String > selection
    )
    throws RemoteException,
    MXException {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        setChangedFlag();
        if (selection.size() > 0) {
            Iterator < String > itr = selection.iterator();
            _modelLocation = modelLocation;
            while (itr.hasNext()) {
                String sel = itr.next();
                if (setCurrentSelection(sel)) {
                    break;
                }
            }
        }

        // _multiSelect is set to null as soon as the .jsp reads it.  _currentSelection
        // persists until changed by a new selection
        _currentSelection = selection;
        _multiSelection = selection;
        _multeSelectZoomToContext = true;
    }

    //**************************************************************************
    // This section has various query functions call both from this class and
    // from dialogs launched from this class
    //**************************************************************************
    /**
     * Gets the starting location for search for a model file.  If this is an asset
     * the the location is the location attribute of the asset.  If this is a location
     * the the location is itself
     * @return
     * @throws RemoteException
     * @throws MXException
     */
    protected Location lookupLeafLocation()
    throws RemoteException,
    MXException {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        MboRemote mbo = null;
        if (getRecordType() == BIMViewer.RECORD_ASSET) {
            String locName = dataBean.getString(FIELD_LOCATION);
            if (locName == null || locName.length() == 0) return null;
            mbo = lookupLocation(locName);
            //System.out.println(">>> BIMViewer component lookupLeafLocation BIMViewer.RECORD_ASSET, mbo: " + mbo);
            if (mbo != null && mbo instanceof Location) {
                return (psdi.app.location.Location) mbo;
            }
            return null;
        } else if (getRecordType() == RECORD_LOCATION) {
            //System.out.println(">>> BIMViewer component lookupLeafLocation attempting YES reset(): " + dataBean.getMboSet().getCompleteWhere());
            //			boolean doReset = false;
            //	        if(dataBean.getMboSet().getAppWhere() == null)
            //	        {
            //	        	dataBean.getMboSet().setAppWhere("");
            //	        	doReset = true;
            //	        }
            //	        if(dataBean.getMboSet().getQbeWhere() != null && !dataBean.getMboSet().getQbeWhere().equalsIgnoreCase(""))
            //	        {
            //	        	dataBean.getMboSet().setRelationship("");
            //	        	doReset = true;
            //	        }
            //	        if(doReset)
            //	        {
            //		        dataBean.getMboSet().reset();
            //	        }
            mbo = dataBean.getMbo(0);
            //System.out.println(">>> BIMViewer component lookupLeafLocation (mbo == null): " + (mbo == null));
            //System.out.println(">>> BIMViewer component lookupLeafLocation RECORD_LOCATION, dataBean.getMboSet().getName(): " + dataBean.getMboSet().getName() + " dataBean: " + dataBean);
            //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getAppWhere()): " + dataBean.getMboSet().getAppWhere());
            //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getQbeWhere()): " + dataBean.getMboSet().getQbeWhere());
            //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getSelectionWhere()): " + dataBean.getMboSet().getSelectionWhere());
            //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getUserWhere()): " + dataBean.getMboSet().getUserWhere());
            //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getWhere()): " + dataBean.getMboSet().getWhere());
            //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getRelationship()): " + dataBean.getMboSet().getRelationship() );
            //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getCompleteWhere())4: " + dataBean.getMboSet().getCompleteWhere());
            if (mbo != null && mbo instanceof Location) {
                //System.out.println(">>> BIMViewer component lookupLeafLocation (mbo != null): " + (mbo != null));
                //System.out.println(">>> BIMViewer component lookupLeafLocation (mbo instanceof Location): " + (mbo instanceof Location));
                return (psdi.app.location.Location) mbo;
            } else {
                //System.out.println(">>> BIMViewer component lookupLeafLocation (dataBean.getMboSet().getQbeWhere() != null): " + (dataBean.getMboSet().getQbeWhere() != null) );
                if (dataBean.getMboSet().getQbeWhere() != null && !dataBean.getMboSet().getQbeWhere().equals("")) // if the qbewhere has been set, use that
                {
                    //					MboSetRemote locationSet = null;
                    //					locationSet = _server.getMboSet( Constants.TABLE_LOCATIONS, dataBean.getMboSet().getUserInfo() );
                    //					locationSet.setWhere( dataBean.getMboSet().getQbeWhere() );
                    //					locationSet.reset();
                    String oldQBEWhere = dataBean.getMboSet().getQbeWhere();
                    dataBean.getMboSet().clear();
                    //System.out.println(">>> BIMViewer component lookupLeafLocation QBE updating dataBean with clear()" );
                    //System.out.println(">>> BIMViewer component lookupLeafLocation RECORD_LOCATION, dataBean.getMboSet().getName(): " + dataBean.getMboSet().getName() + " dataBean: " + dataBean);
                    //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getAppWhere()): " + dataBean.getMboSet().getAppWhere());
                    //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getQbeWhere()): " + dataBean.getMboSet().getQbeWhere());
                    //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getSelectionWhere()): " + dataBean.getMboSet().getSelectionWhere());
                    //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getUserWhere()): " + dataBean.getMboSet().getUserWhere());
                    //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getWhere()): " + dataBean.getMboSet().getWhere());
                    //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getRelationship()): " + dataBean.getMboSet().getRelationship() );
                    //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getCompleteWhere())4.1: " + dataBean.getMboSet().getCompleteWhere());
                    dataBean.getMboSet().setWhere(oldQBEWhere);
                    dataBean.reset();
                    //					mbo = locationSet.getMbo(0);
                    mbo = dataBean.getMboSet().getMbo(0);
                    //			        //System.out.println(">>> BIMViewer component lookupLeafLocation getting mbo with QBEWHERE instead: " + locationSet.getCompleteWhere());
                    //System.out.println(">>> BIMViewer component lookupLeafLocation getting mbo with QBEWHERE instead: " + dataBean.getMboSet().getCompleteWhere());
                    return (psdi.app.location.Location) mbo;
                }
                //System.out.println(">>> BIMViewer component lookupLeafLocation where poplulated and relationship populated: " + (dataBean.getMboSet().getWhere() != null && !dataBean.getMboSet().getWhere().equals("") && dataBean.getMboSet().getRelationship() != null && !dataBean.getMboSet().getRelationship().equals("")) );
                if (dataBean.getMboSet().getWhere() != null && !dataBean.getMboSet().getWhere().equals("") &&
                    dataBean.getMboSet().getRelationship() != null && !dataBean.getMboSet().getRelationship().equals("")) // if there's a where, the relationship may be conflicting
                {
                    //					MboSetRemote locationSet = null;
                    //					locationSet = _server.getMboSet( Constants.TABLE_LOCATIONS, dataBean.getMboSet().getUserInfo() );
                    //					locationSet.setRelationship("");
                    //					locationSet.setWhere( dataBean.getMboSet().getWhere() );
                    //					locationSet.reset();
                    String oldWhere = dataBean.getMboSet().getWhere();
                    //dataBean.getMboSet().clear();
                    //dataBean.clearBean();
                    cleandDatabeanWhere(dataBean);
                    //System.out.println(">>> BIMViewer component lookupLeafLocation WHERE updating dataBean with cleandDatabeanWhere(dataBean)" );
                    //System.out.println(">>> BIMViewer component lookupLeafLocation RECORD_LOCATION, dataBean.getMboSet().getName(): " + dataBean.getMboSet().getName() + " dataBean: " + dataBean);
                    //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getAppWhere()): " + dataBean.getMboSet().getAppWhere());
                    //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getQbeWhere()): " + dataBean.getMboSet().getQbeWhere());
                    //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getSelectionWhere()): " + dataBean.getMboSet().getSelectionWhere());
                    //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getUserWhere()): " + dataBean.getMboSet().getUserWhere());
                    //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getWhere()): " + dataBean.getMboSet().getWhere());
                    //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getRelationship()): " + dataBean.getMboSet().getRelationship() );
                    //System.out.println(">>> BIMViewer component lookupLeafLocation dataBean.getMboSet().getCompleteWhere())4.2: " + dataBean.getMboSet().getCompleteWhere());
                    dataBean.getMboSet().setWhere(oldWhere);
                    dataBean.reset();
                    //					mbo = locationSet.getMbo(0);
                    mbo = dataBean.getMboSet().getMbo(0);
                    //			        //System.out.println(">>> BIMViewer component lookupLeafLocation getting mbo with ONLY WHERE instead: " + locationSet.getCompleteWhere());
                    //System.out.println(">>> BIMViewer component lookupLeafLocation getting mbo with ONLY WHERE instead: " + dataBean.getMboSet().getCompleteWhere());
                    return (psdi.app.location.Location) mbo;
                }
            }
            return null;
        }
        //System.out.println(">>> BIMViewer component lookupLeafLocation end, getRecordType(): " + getRecordType());
        return null;
    }

    private void cleandDatabeanWhere(DataBean dataBean) throws RemoteException, MXException {
        dataBean.getMboSet().setAppWhere("");
        dataBean.getMboSet().resetQbe();
        dataBean.getMboSet().setUserWhere("");
        dataBean.getMboSet().setWhere("");
        dataBean.getMboSet().setRelationship("");
    }

    protected MboSetRemote lookupModelFileForLocation(
        LocationRemote locMbo
    ) {
        //System.out.println(">>> BIMViewer component lookupModelFileForLocation " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        try {
            String siteId = locMbo.getString(FIELD_SITEID);
            String orgId = locMbo.getString(FIELD_ORGID);
            String systemId = locMbo.getString(FIELD_SYSTEMID);
            String location = locMbo.getString(FIELD_LOCATION);
            String viewerTypeList = _modelSet.getVieweerTypeList(siteId, orgId);

            if (systemId == null || systemId.length() == 0) {
                SqlFormat sqlPrimarySystem = new SqlFormat(locMbo, "siteid=:1 AND PRIMARYSYSTEM=1");
                sqlPrimarySystem.setObject(1, "LOCSYSTEM", "SITEID", siteId);
                MboSetRemote primarySystemSet = locMbo.getMboSet("$getSystems", "LOCSYSTEM", sqlPrimarySystem.format());
                String[] params = {
                    location,
                    siteId
                };
                if (primarySystemSet.isEmpty()) {
                    throw new MXApplicationException(Constants.BUNDLE_MSG,
                        Constants.ERR_NO_PRIMARY_SYS, params);
                }
                MboRemote ancestorMbo = primarySystemSet.getMbo(0);
                systemId = ancestorMbo.getString("SYSTEMID");
            }

            StringBuffer query = new StringBuffer("( ");
            query.append(QUERY_MODEL_FILE);
            query.append(" )");
            query.append(" AND ");
            query.append(" ( ");
            query.append(BuildingModel.FIELD_VIEWERTYPE);
            query.append(" IN ( ");
            query.append(viewerTypeList);
            query.append(" )");

            // To support legacy installations, treat all models that don't have a value for viewerType as NavisWorks
            if (_activeViewer.equals("navisworks")) {
                query.append("OR (");
                query.append(BuildingModel.FIELD_VIEWERTYPE);
                query.append(" IS NULL");
                query.append(" )");
            }

            query.append(")");

            SqlFormat sqlf;
            sqlf = new SqlFormat(query.toString());
            sqlf.setObject(1, TABLE_LOCATIONS, FIELD_LOCATION, location);
            sqlf.setObject(2, TABLE_LOCATIONS, FIELD_SITEID, siteId);
            sqlf.setObject(3, TABLE_LOCATIONS, FIELD_SYSTEMID, systemId);
            //System.out.println(">>> BIMViewer component lookupModelFileForLocation sqlf.format(): " + sqlf.format() );
            //System.out.println(">>> BIMViewer component lookupModelFileForLocation _modelSet.getCompleteWhere(): " + _modelSet.getCompleteWhere() );
            _modelSet.setWhere(sqlf.format());
            _modelSet.setOrderBy(BuildingModel.FIELD_PRIORITY + " DESC");
            _modelSet.reset();

            //System.out.println(">>> BIMViewer component lookupModelFileForLocation _modelSet: " + _modelSet );
            //System.out.println(">>> BIMViewer component lookupModelFileForLocation _modelSet.getName(): " + _modelSet.getName() );
            //System.out.println(">>> BIMViewer component lookupModelFileForLocation _modelSet.getCompleteWhere(): " + _modelSet.getCompleteWhere() );

            return _modelSet;
        } catch (Exception e) {
            //System.out.println(">>> BIMViewer component lookupModelFileForLocation error caught... " );
            e.printStackTrace(System.err);
            return null;
        }
    }


    /**
     * Queries the database for a location record based on location and siteid attributes
     * @param location
     * @return
     * @throws RemoteException
     * @throws MXException
     */
    public LocationRemote lookupLocation(
        String location
    )
    throws RemoteException,
    MXException {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        dataBean.setCurrentRow(0);
        String siteId = dataBean.getString(FIELD_SITEID);
        //System.out.println(">>> BIMViewer component lookupLocation(location) siteId: " + siteId );
        //System.out.println(">>> BIMViewer component lookupLocation(location) dataBean.getMbo(0): " + dataBean.getMbo(0) );
        //System.out.println(">>> BIMViewer component lookupLocation(location) dataBean.getCompleteWhere(): " + dataBean.getCompleteWhere() );
        return BIMViewer.lookupLocation(dataBean.getMbo(0), location, siteId);
    }

    /**
     * Use the value of an item in the model to find the Maximo location for that
     * item using the current dataattibute binding of the control
     * 
     * Used by dialogs that include or are launched by the control
     * @param value The value of the datafield bound to the control.  Usually is modelid
     * @return 
     * @throws RemoteException
     * @throws MXException
     */
    public LocationRemote lookupLocationFromModelId(
        String modelId
    )
    throws RemoteException,
    MXException {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        String siteId = dataBean.getString(FIELD_SITEID);
        return lookupLocationFromModelId(_modelLocation, modelId, siteId);
    }

    public LocationRemote lookupLocationFromModelId(
        String modelLocation,
        String modelId
    )
    throws RemoteException,
    MXException {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        String siteId = dataBean.getString(FIELD_SITEID);
        return lookupLocationFromModelId(modelLocation, modelId, siteId);
    }

    /**
     * Get the location from the bound value if the control is bound to either location of asset
     * @param location
     * @return
     * @throws RemoteException
     * @throws MXException
     */
    public LocationRemote lookupLocationFromModelId(
        String modelLocation,
        String modelId,
        String siteId
    )
    throws RemoteException,
    MXException {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        if (modelLocation == null) {
            return null;
        }

        String field = _binding;
        if (_recordType == RECORD_ASSET) field = _modelId;

        try {
            SqlFormat sqlf = new SqlFormat(dataBean.getMbo(0), field + QUERY_LOC_MODELID);
            sqlf.setObject(1, TABLE_LOCATIONS, _modelId, modelId);
            sqlf.setObject(2, TABLE_LOCATIONS, FIELD_LOCATION, modelLocation);
            sqlf.setObject(3, TABLE_LOCATIONS, FIELD_SITEID, siteId);
            MboSetRemote locSet = dataBean.getMbo(0).getMboSet("$getLocations", TABLE_LOCATIONS, sqlf.format());
            if (locSet.isEmpty()) return null;
            if (locSet.count() > 1) {
                // TO DO issue error
            }
            return (LocationRemote) locSet.getMbo(0);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Looks up a location based on the datasrc for the control (Usually modelId)
     * @param location
     * @param siteId
     * @return The location field of the location associated with the imput value, or null
     * @throws RemoteException
     * @throws MXException
     */
    public String lookupLocationModelId(
        String location,
        String siteId
    )
    throws RemoteException,
    MXException {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        if (_binding.equalsIgnoreCase(FIELD_LOCATION)) {
            return location;
        }
        String field = _binding;
        if (_type == TYPE_ASSET) field = _modelId;

        MboRemote locMbo = BIMViewer.lookupLocation(dataBean.getMbo(0), location, siteId);
        if (locMbo == null) return null;
        return locMbo.getString(field);
    }

    /**
     * SQL Lookup of the location associated with a work order
     * @param woKey
     * @param siteId
     * @return
     */
    public String lookupLocationFromWO(
        String woKey,
        String siteId
    ) {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        MboRemote mbo;
        try {
            mbo = dataBean.getMbo(0);
            SqlFormat sqlf = new SqlFormat(mbo, FIELD_WO_NUM + "=:1 and siteid=:2");
            sqlf.setObject(1, TABLE_WORKORDER, FIELD_WO_NUM, woKey);
            sqlf.setObject(2, TABLE_WORKORDER, FIELD_SITEID, siteId);
            MboSetRemote resultSet = mbo.getMboSet("$getWorkOrder", TABLE_WORKORDER, sqlf.format());
            if (resultSet.isEmpty()) {
                return null;
            }
            MboRemote resultMbo = resultSet.getMbo(0);
            String location = resultMbo.getString(FIELD_LOCATION);

            // Figure out which field is bound to the model and return the value fo it
            String field = _binding;
            if (_type == TYPE_ASSET) field = _modelId;
            if (field.equalsIgnoreCase(FIELD_LOCATION)) {
                return location;
            }
            resultMbo = BIMViewer.lookupLocation(mbo, location, siteId);
            return resultMbo.getString(field);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Get a building model definition associated with a location if one exists
     * @param location
     * @return
     * @throws RemoteException
     * @throws MXException
     */
    protected MboSetRemote lookupModelsForLocation(
        String location
    )
    throws RemoteException,
    MXException {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        MboRemote mbo = dataBean.getMbo(0);
        String siteId = dataBean.getString(FIELD_SITEID);

        SqlFormat sqlf = new SqlFormat(mbo, "location=:1 and siteid=:2");
        sqlf.setObject(1, BIMModelSpec.TABLE_BUILDINGMODEL, FIELD_LOCATION, location);
        sqlf.setObject(2, BIMModelSpec.TABLE_BUILDINGMODEL, FIELD_SITEID, siteId);
        return mbo.getMboSet("$getBuildingModel", BIMModelSpec.TABLE_BUILDINGMODEL, sqlf.format());
    }

    /**
     * <p>Get the UID for the Maximo record associated with the modelId<p>
     * Model IDs always refer t locations so if the control is bound to asset
     * The asset at the location must be queried.  It is assumed the operating locations
     * are used and therefore there is no more than one asset at a location
     * @param locationId	The location for the model.  Used to disambiguate the modelId
     * @param modelId
     * @param siteId
     * @return Unique identifier for location or asset associated with a model ID 
     * @throws MXException 
     * @throws RemoteException 
     */
    protected long lookupUid(
        String modelId
    )
    throws RemoteException,
    MXException {
    	
    	String mboName = null;
    	UserInfo uInfo = null;
    	if(dataBean != null && dataBean.getMboSet() != null)
    	{
    		mboName = dataBean.getMboSet().getName();
    		uInfo = dataBean.getMboSet().getUserInfo();
    		
    	} else {
    		AppInstance app = getWebClientSession().getCurrentApp();
    		mboName = app.getDataBean().getMboSet().getName();
    		uInfo = app.getDataBean().getMboSet().getUserInfo();
    	}
    	
    	if(mboName != null && uInfo != null) {
        	MboSetRemote lookupMboSet = MXServer.getMXServer().getMboSet(mboName, uInfo);
        	//String whereClause = getProperty(PROP_DATA_ATTRIB) + " = '" + modelId + "'";
        	String whereClause = _modelId + " = '" + modelId + "'";
        	if(lookupMboSet.getMboSetInfo().getSiteOrgType() != MboSetInfo.SYSTEMLEVEL0) {
        		whereClause += "and orgid = '" + lookupMboSet.getProfile().getDefaultOrg() + "'";
        	}
        	lookupMboSet.setWhere(whereClause);
        	lookupMboSet.reset();
        	MboRemote lookupMbo = lookupMboSet.getMbo(0);
        	if(lookupMbo != null) {
        		return lookupMbo.getUniqueIDValue();
        	}
    	}
    	
    	return -1;
    	
//        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
//        if (_modelLocation == null) {
//            return -1;
//        }
//        if (_recordType != RECORD_LOCATION && _recordType != RECORD_ASSET) {
//            return -1;
//        }
//
//        String siteId = dataBean.getString(FIELD_SITEID);
//        MboRemote mbo = dataBean.getMbo(0);
//        SqlFormat sqlf = new SqlFormat(mbo, _modelId + QUERY_LOC_MODELID);
//        sqlf.setObject(1, TABLE_LOCATIONS, _modelId, modelId);
//        sqlf.setObject(2, TABLE_LOCATIONS, FIELD_LOCATION, _modelLocation);
//        sqlf.setObject(3, TABLE_LOCATIONS, FIELD_SITEID, siteId);
//        String query = sqlf.format();
//        MboSetRemote resultSet = mbo.getMboSet("$getLocationsSet", TABLE_LOCATIONS, query);
//        if (_recordType == RECORD_LOCATION) {
//            if (!resultSet.isEmpty()) {
//                MboRemote resultMbo = resultSet.getMbo(0);
//                return resultMbo.getLong("LOCATIONSID");
//            }
//            return -1;
//        }
//
//        boolean matchLocation = true;
//        // Record type is ASSET
//        if (resultSet.isEmpty()) {
//            resultSet = mbo.getMboSet("$getAssetSet", TABLE_ASSET, query);
//            matchLocation = false;
//        }
//        if (resultSet.isEmpty()) {
//            return -1;
//        }
//
//        MboRemote resultMbo = resultSet.getMbo(0);
//
//        if (matchLocation) {
//            resultSet = BIMViewer.lookupAssetsAtLocation(resultMbo);
//            if (resultSet.isEmpty()) {
//                return -1;
//            }
//        }
//        resultMbo = resultSet.getMbo(0);
//        return resultMbo.getLong("ASSETUID");
    }

    /**
     * Compare two lists of model specification
     * @param list1
     * @param list2
     * @return true if the list are identical
     */
    private boolean compareModelLists(
        Vector < BIMModelSpec > list1,
        Vector < BIMModelSpec > list2
    ) {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        if (list1 == null && list2 == null) return true;
        if (list1 == null || list2 == null) return false;
        if (list1.size() != list2.size()) return false;
        for (int i = 0; i < list1.size(); i++) {
            if (!list1.get(i).equals(list2.get(i))) return false;
        }
        return true;
    }

    static public BaseInstance findByRenderId(
        BaseInstance root,
        String renderId
    ) {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        String altRenderId = "NO MATCH";
        int idx = renderId.indexOf('_');
        if (idx > 0) {
            altRenderId = renderId.replaceFirst("_", "-");;
            //			renderId = renderId.substring( 0, idx );
        }
        if (root == null) return root;
        if (root.getRenderId().equals(renderId) || root.getRenderId().equals(altRenderId)) {
            return root;
        }

        List < ? > l;
        if (root instanceof ControlInstance) {
            l = ((ControlInstance) root).getComponents();
        } else {
            l = root.getChildren();
        }
        Iterator < ? > itr = l.iterator();
        while (itr.hasNext()) {
            Object o = itr.next();
            if (!(o instanceof BaseInstance)) continue;
            BaseInstance bi = (BaseInstance) o;
            if (bi.getRenderId().equals(renderId) || bi.getRenderId().equals(altRenderId)) {
                return bi;
            }
            bi = findByRenderId(bi, renderId);
            if (bi != null) return bi;
        }
        return null;
    }

    /**
     * Queries the database for a location record based on location and siteid attributes
     * @param location
     * @return
     * @throws RemoteException
     * @throws MXException
     */
    public static LocationSetRemote lookupLocations(
        MboRemote mbo,
        String location,
        String siteId
    )
    throws RemoteException,
    MXException {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        //System.out.println(">>> BIMViewer component lookupLocations mbo: " + mbo + " location: " + location + " siteId: " + siteId );
        if (mbo == null) {
            return null;
        }

        SqlFormat sqlf = new SqlFormat(mbo, FIELD_LOCATION + "=:1 and siteid=:2");
        sqlf.setObject(1, TABLE_LOCATIONS, FIELD_LOCATION, location);
        sqlf.setObject(2, TABLE_LOCATIONS, FIELD_SITEID, siteId);
        //System.out.println(">>> BIMViewer component lookupLocations sqlf.format(): " + (sqlf.format()) );
        return (LocationSetRemote) mbo.getMboSet("$getLocations", TABLE_LOCATIONS, sqlf.format());
    }

    /**
     * Queries the database for a location record based on location and siteid attributes
     * @param location
     * @return
     * @throws RemoteException
     * @throws MXException
     */
    public static LocationRemote lookupLocation(
        MboRemote mbo,
        String location,
        String siteId
    )
    throws RemoteException,
    MXException {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        MboSetRemote locationSet = lookupLocations(mbo, location, siteId);
        //System.out.println(">>> BIMViewer component ( locationSet == null || locationSet.isEmpty())?: " + ( locationSet == null || locationSet.isEmpty()));
        if (locationSet == null || locationSet.isEmpty()) {
            return null;
        }
        return (LocationRemote) locationSet.getMbo(0);
    }

    /**
     * Get all the assets at the specified location
     * @param locationMbo
     * @return null or a set of assets
     */
    public static MboSetRemote lookupAssetsAtLocation(
        MboRemote locationMbo
    ) {
        //System.out.println(">>> BIMViewer component " + (Thread.currentThread().getStackTrace()[3].toString()) + " ==> " + ((new Object() {}).getClass().getEnclosingMethod().getName()) );
        if (locationMbo == null) return null;

        try {
            String location = locationMbo.getString(FIELD_LOCATION);
            String siteId = locationMbo.getString(FIELD_SITEID);

            SqlFormat sqlf = new SqlFormat(locationMbo, FIELD_LOCATION + "=:1 and siteid=:2");
            sqlf.setObject(1, TABLE_ASSET, FIELD_LOCATION, location);
            sqlf.setObject(2, TABLE_ASSET, FIELD_SITEID, siteId);
            MboSetRemote assetSet = locationMbo.getMboSet("$getAssetSet", TABLE_ASSET, sqlf.format());
            return assetSet;
        } catch (Exception e) {
            return null;
        }
    }

    private void changeBeanRecordSet(DataBean bean, long uid) throws RemoteException, MXException {
        bean.getMboSet().resetQbe();
        bean.getMboSet().clear();
        bean.getMboSet().setWhere(bean.getUniqueIdName() + " = " + uid);
        bean.getMboSet().reset();
    }

    /**
     * Holds the definition of a building model
     * @author Doug
     *
     */
}